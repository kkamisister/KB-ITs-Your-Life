function test() {
  console.log('called test()....');
}

console.log(test());
console.log();
