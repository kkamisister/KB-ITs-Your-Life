<script>
export default {
  name: 'Test1Parent',
  data() {
    return {}
  },
}
</script>

<template>
  <div class="test1parent">연습을 시작한다</div>
</template>

<style scoped></style>
