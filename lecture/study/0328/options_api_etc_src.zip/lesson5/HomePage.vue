<script>
export default {
  name: 'HomePage',
}
</script>

<template>
  <div class="home-page">
    <h2>홈</h2>
    <p>Vue 3 동적 컴포넌트 예제의 홈페이지입니다.</p>
  </div>
</template>
