import { createApp } from 'vue';
import App from './App3.vue';
//import App from './App2.vue';

import './assets/main.css';

// createApp(App).component('CheckboxItem', CheckboxItem).mount('#app');
createApp(App).mount('#app');
