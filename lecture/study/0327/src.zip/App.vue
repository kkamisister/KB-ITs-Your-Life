<script>
import Lesson1Parent from './lesson1/Lesson1Parent.vue'
import Lesson2Parent from './lesson2/Lesson2Parent.vue'

export default {
  name: 'App',
  components: { Lesson1Parent, Lesson2Parent },
}
</script>

<template>
  <div class="app">
    <h1>app 영역</h1>
    <Lesson1Parent />
    <Lesson2Parent />
  </div>
</template>

<style scoped>
.app {
  border: 1px solid red;
  padding: 1rem;
  margin: 1rem;
}
</style>
