<script>
import CheckBox2 from '@/lesson1/CheckBox2.vue'

export default {
  name: 'Lesson2Parent',
  components: { CheckBox2 },
  data() {
    return {
      items: [
        { id: 1, label: '김밥', checked: false },
        { id: 2, label: '떡볶이', checked: false },
        { id: 3, label: '만두', checked: false },
        { id: 4, label: '오댕', checked: false },
        { id: 5, label: '순대', checked: true },
      ],
    }
  },
}
</script>

<template>
  <div class="lesson2parent">
    <h2>lesson2</h2>
    <CheckBox2 v-for="item in items" :key="item.id" :item="item" />
  </div>
</template>

<style scoped>
.lesson2parent {
  border: 1px solid tomato;
}
</style>
