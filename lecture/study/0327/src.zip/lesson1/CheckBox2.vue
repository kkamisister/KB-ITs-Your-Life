<script>
export default {
  name: 'CheckBox2',
  data() {
    return {}
  },
  props: {
    item: {
      type: Object,
      requried: true,
    },
  },
}
</script>

<template>
  <div class="checkbox2">
    <input type="checkbox" :checked="item.checked" />
    <label for="item.id">{{ item.label }}</label>
  </div>
</template>

<style scoped></style>
