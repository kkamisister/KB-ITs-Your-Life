<script>
export default {
  name: 'CheckBox',
  data() {
    return {}
  },
  // 1. 배열 형태
  // props: ['id', 'labelName'],

  // 2. 타입 지정
  // props: {
  //   id: String,
  //   labelName: String,
  // },

  // 3. 타입과 속성 지정
  props: {
    id: { type: String, required: true },
    labelName: { type: String, required: true },
  },
}
</script>

<template>
  <div class="CheckBox">
    <label :for="id">{{ labelName }}</label> :
    <input :id="id" type="text" :value="id" />
  </div>
</template>

<style scoped>
.CheckBox {
  border: 2px solid tomato;
  padding: 1rem;
}
</style>
