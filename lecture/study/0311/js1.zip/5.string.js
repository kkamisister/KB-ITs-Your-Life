/**
 * 문자열타입
 */

let str1 = '안녕';
let str2 = '소영이다';
let str3 = `문자열과 함께 

변수도 사용가능
 - ${str1}, ${str2}`;
console.log(str3);

// 특수문자
