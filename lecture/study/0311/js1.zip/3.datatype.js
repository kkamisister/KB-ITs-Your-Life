/**
 * 데이터 타입의 종류
 * number 숫자
 * string 문자
 * boolean 불 참, 거짓
 * null 비었다
 * undefined 정의되지 않았다.
 * symbol
 * object 객체
 *
 * 원시타입 / 객체타입
 */

let num = 1;
let name = '길동이';
let isFree = false;
let sample = '';
console.log('sample-', sample);

const obj1 = {
  a: 'test1',
  b: () => {},
  c: [],
  d: {},
};

console.log(obj1.a);
