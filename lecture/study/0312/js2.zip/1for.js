// 제어문 - 반복문 (for)
/**
 * 실행순서
 * 1. 변수선언문 실행으로 변수 초기화
 * 2. 조건식의 값이 참이면 {} 코드블럭을 수행
 * 3. 증감식 수행
 * 4. 조건식이 거짓이 될 때까지 2,3번을 반복
 */

// 구구단 출력해 보기~
for (let i = 0; i < 5; i++) {
  console.log(i);
  for (let j = 0; j < 5; j++) {
    console.log('--', j);
  }
}

// 무한반복 되지 않도록 주의!
// 조건은 언젠가는 거짓이 되어야 한다!
// for(;;){}

// 반복문 제어 - continue(건너뛴다) , break(코드종료한다)
console.clear();
for (let a = 0; a < 20; a++) {
  if (a === 10) {
    continue;
    console.log('10입니다');
    // break;
  }
  console.log(a);
}

// 반복문은 배열과 객체 데이터를 다룰 때 많이 사용됨
console.clear();
let friuts = ['사과', '바나나', '체리', '포도'];

// console.log(friuts[0]);
console.log(friuts.length);
for (let i = 0; i < friuts.length; i++) {
  console.log('-------');
  console.log(friuts[i]);
}

// forEach()
friuts.forEach((friut, i, arr) => {
  //   console.log('foreach');
  console.log(friut);
  //   console.log(i);
  //   console.log(arr);
  console.log('-----');
});

for (let friut of friuts) {
  console.log(friut);
}

// 객체를 반복문으로 출력
let members = {
  manager: '한식이',
  designer: '두식이',
  devel: '세식이',
};

for (let m in members) {
  console.log(members[m]);
}
console.log(members.manager);
