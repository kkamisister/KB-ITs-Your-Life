// 객체 {}, 배열 []

// 함수() - 특정한 일을 수행하는 코드의 집합
// 선언함수, 익명함수, 화살표 함수 등이 있음

// 선언함수 : function 함수이름(){}
// 익명함수 : function (){}
// 화살표 함수 : ()=>{}

// 함수는 호출이 일어나기 전 까지 실행되지 않음
console.clear();
function add() {
  console.log('함수를 호출했다');
}
add();

//
function add2(a, b) {
  console.log('함수내부');
  //   console.log(a);
  //   console.log(b);
  console.log(arguments);
  console.log(arguments['0']);

  return a + b;
}
let result = add2(2, 5);
console.log(result);

// fullName('소영','박') // 소영 박
// fullName('삼식','김') // 삼식 김

// function add3(a, b) {
//   //   return a + b;
//   console.log('test');
// //   return undefined
// }
function add3(a, b) {
  //   return a + b;
  return;
  //   return undefined
}

// 함수명은 함수가 저장된 heap 주소를 할당받은 것임
let add4 = (a, b) => a + b;
// let sum = add4;
// console.log(add4(2, 3));
// console.log(sum(1, 3));

// retrun 의 활용
// 함수를 일찍 종료할 때,
// 조건에 맞지 않으면 하위 코드를 실행할 필요가 없을 때
function print(num) {
  if (num < 0) {
    return;
  }
  console.log(num);
}
print(-12);
