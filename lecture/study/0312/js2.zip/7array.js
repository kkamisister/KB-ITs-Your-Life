// 배열과 함께 사용하는 함수들
let fruits = ['사과', '배', '복숭아'];

console.clear();
// 추가 - 제일 뒤
fruits.push('딸기');
console.log(fruits);

// 추가 - 제일 앞
fruits.unshift('망고');
console.log(fruits);

// 제거 - 제일 뒤
fruits.pop();
console.log(fruits);

// 제거 - 제일 앞
fruits.shift();
console.log(fruits);

// 중간에 삭제 혹은 추가
fruits.splice(0, 2);
console.log(fruits);
fruits.splice(0, 2, '추가1', '추가2');
console.log(fruits);

// 배열과 배열을 병합
let arr1 = [1, 2, 3];
let arr2 = [5, 6, 7];
let arr3 = arr1.concat(arr2);
console.log(arr3);

// 설명 추가합니다~~~

//push, unshift 등으로 처리한 값을 반환할 때는 배열의 길이 반환(length)를 반환합니다.
let num = fruits.pop('참외');
console.log(num); // 배열의 길이 반환

//pop, shift, splice 는 제거된 아이템을 반환
let lastItem = fruits.pop();
console.log(lastItem); // 제거된 아이템 반환

// 특정한 아이템의 위치를 찾을때
console.log(fruits.indexOf('배'));

// flat()
// fill()
// join()

// 배열과 함께 쓰이는 고차함수
// forEach, find, findIndex, some, every, filter, map, flatmap, sort, reduce
